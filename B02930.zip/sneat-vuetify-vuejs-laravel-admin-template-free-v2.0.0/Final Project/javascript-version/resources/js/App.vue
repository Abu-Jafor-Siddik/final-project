<script setup>
import UpgradeToPro from '@/components/UpgradeToPro.vue'
</script>

<template>
  <VApp>
    <RouterView />
    <UpgradeToPro />
  </VApp>
</template>
